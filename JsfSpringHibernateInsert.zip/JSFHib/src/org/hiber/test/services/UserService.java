package org.hiber.test.services;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hiber.test.objmodel.User;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class UserService {
	
	@PersistenceContext
	private EntityManager em;
	
	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}
	
	@Transactional
	public void register(User user) {
		// Save employee
		this.em.merge(user);
	}

}
